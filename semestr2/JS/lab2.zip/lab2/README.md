# Lab 2 - Promise and async/await

## Running the project

In order to run the project locally, install Node.js and static-server package.

- Please, refer to the [official guide](https://nodejs.org/en/download) on how to install Node.js
- To install static-server, run the following command or open [official documentation](https://www.npmjs.com/package/static-server#getting-started)

```
    npm -g install static-server
```

- Run the following in command line from the project directory:

```
    static-server
```

## getActivity functions

There are 3 options of getActivity functions in activity.js
The first one (getActivity) uses promises and .then method to get and insert data
The second one (getActivityAsync) uses async/await syntax to get and insert data
The third one (getActivityAsyncTwo) uses same syntax as the second one, but returns data only. In order to populate html element with the data that getActivityAsyncTwo returns, updateActivity is used.

The currently used option can be changed by modifying index.js file providing a desired option number.

```javascript
const option = 1;
```
